export const TechnologyList = [
  {
    technologyId: 1,
    technologyName: "React JS",
    category: "Library",
    features: [
      "Developed by Facebook",
      "UI Development Library",
      "Virtual DOM",
      "JSX",
    ],
    currentVersion: "17.x",
    mostAppreciatedFeature: "React Hooks",
    releaseYear: 2013,
    ranking: 1,
    logo: "images/react-logo.png",
  },
  {
    technologyId: 2,
    technologyName: "Angular",
    category: "Framework",
    features: [
      "Developed by Google",
      "Component based Development",
      "Routing",
      "Typescript",
    ],
    currentVersion: "12.x",
    mostAppreciatedFeature: "Single Page Application",
    releaseYear: 2016,
    ranking: 2,
    logo: "images/ng-logo.png",
  },
  {
    technologyId: 3,
    technologyName: "Vue JS",
    category: "Framework",
    features: [
      "Open Source",
      "Component based Development and Single Page Application",
      "Routing",
      "ECMAScript and Typescript",
    ],
    currentVersion: "3.x",
    mostAppreciatedFeature: "Single Page Application",
    releaseYear: 2014,
    ranking: 3,
    logo: "images/vue-logo.png",
  },
];
export const AngularQuestions = [
  {
    questionId: 1,
    question: "How many projects you are currently developing using Angular framework?",
    answers: [1, 2, 3, 4, "More"]
  },
  {
    questionId: 2,
    question: "How do you rate your experience with Angular Dependency Injection?",
    answers: [1, 2, 3, 4, 5]
  },
  {
    questionId: 3,
    question: "Are you developing Single Page Application using Angular framework?",
    answers: ["Yes", "No"]
  },
  {
    questionId: 4,
    question: "Which version of Angular framework you are currently using in your development?",
    answers: [9, 10, 11, 12]
  },
  {
    questionId: 5,
    question: "Are you using HTTP Interceptors in your current project?",
    answers: ["Yes", "No"]
  },
  {
    questionId: 6,
    question: "Are you protecting your routes using route guards?",
    answers: ["Yes", "No"]
  },
  {
    questionId: 7,
    question: "Are you using feature wise module development in your application?",
    answers: ["Yes", "No"]
  },
  {
    questionId: 8,
    question: "Are you lazy loading your modules?",
    answers: ["Yes", "No"]
  },
  {
    questionId: 9,
    question: "How was your experience with Angular component development?",
    answers: [1, 2, 3, 4, 5]
  },
  {
    questionId: 10,
    question: "What is your overall rating for Angular framework?",
    answers: [1, 2, 3, 4, 5]
  }
]
