import { Component, OnChanges, Input, SimpleChanges, OnDestroy } from '@angular/core';
import { Subscription } from "rxjs";

import { Technology } from "../../models/technology";

import { TechnologyService } from "../../services/technology.service";

@Component({
  selector: 'technology-details',
  templateUrl: './technology-details.component.html',
  styleUrls: ['./technology-details.component.css']
})
export class TechnologyDetailsComponent implements OnChanges, OnDestroy {

  constructor(private _technologyService: TechnologyService) {

  }

  public title: string = "Details Of - ";
  @Input("technologyId") technologyId: number;
  public technology: Technology;
  private _subscription: Subscription;
  ngOnChanges(change: SimpleChanges): void {
    console.log(JSON.stringify(change));
    this._subscription = this._technologyService.getTechnologyDetails(this.technologyId).subscribe(
      data => this.technology = data,
      error => console.log(error)
    );
  }
  ngOnDestroy(): void {
    if (this._subscription) this._subscription.unsubscribe();
  }
}
