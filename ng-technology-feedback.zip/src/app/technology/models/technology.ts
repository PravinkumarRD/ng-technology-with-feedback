export class Technology {
  public technologyId: number;
  public technologyName: string;
  public category: string;
  public features: string[];
  public currentVersion: string;
  public mostAppreciatedFeature: string;
  public releaseYear: number;
  public ranking: number;
  public logo: string;
}
