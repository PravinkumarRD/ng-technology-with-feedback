import { Technology } from './technology';

describe('Technology', () => {
  it('should create an instance', () => {
    expect(new Technology()).toBeTruthy();
  });
});
