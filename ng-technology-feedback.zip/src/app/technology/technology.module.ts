import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

import { NgxPaginationModule } from 'ngx-pagination';

import { TechnologyListComponent } from './components/technology-list/technology-list.component';
import { TechnologyDetailsComponent } from './components/technology-details/technology-details.component';

import { SearchTechnologyPipe } from './pipes/search-technology.pipe';

import { TechnologyService } from "./services/technology.service";

@NgModule({
  declarations: [
    TechnologyListComponent,
    TechnologyDetailsComponent,
    SearchTechnologyPipe
  ],
  providers:[
    TechnologyService
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgxPaginationModule,
    HttpClientModule
  ],
  exports:[
    TechnologyListComponent
  ]
})
export class TechnologyModule { }
