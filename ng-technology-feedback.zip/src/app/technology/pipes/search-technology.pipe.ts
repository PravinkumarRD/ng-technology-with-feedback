import { Pipe, PipeTransform } from '@angular/core';

import { Technology } from "../models/technology";

@Pipe({
  name: 'searchTechnology'
})
export class SearchTechnologyPipe implements PipeTransform {

  transform(value: Technology[], ...args: string[]): Technology[] {
    if (!value) return value;
    let filterText: string = args[0] ? args[0] : "";
    return value.filter(
      technology => technology.technologyName.toLocaleLowerCase().includes(filterText))
  }
}
