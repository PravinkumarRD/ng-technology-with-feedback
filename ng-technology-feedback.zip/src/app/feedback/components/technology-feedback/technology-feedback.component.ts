import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from "rxjs";

import { NgQuestion } from '../../models/ng-question';
import { UserAnswer } from "../../models/user-answer";

import { FeedbackService } from '../../services/feedback.service';

@Component({
  selector: 'technology-feedback',
  templateUrl: './technology-feedback.component.html',
  styleUrls: ['./technology-feedback.component.css']
})
export class TechnologyFeedbackComponent implements OnInit, OnDestroy {
  constructor(private _feedbackService: FeedbackService) {

  }

  public title: string = "Feedback Of - Angular Framework!";
  public questions: NgQuestion[] = [];
  private _subscription1: Subscription;
  private _subscription2: Subscription;
  public currentQuestion: NgQuestion;
  private _index: number = 0;
  public userAnswers: UserAnswer[] = [];
  public userVote: number = 1;
  public thankYouForFeedback: string = "Thank you very much for your valuable Feedback!";
  ngOnInit(): void {
    this._subscription1 = this._feedbackService.getAngularQuestions().subscribe(
      ngQuestions => {
        this.questions = ngQuestions;
        this.currentQuestion = ngQuestions[0];
      },
      error => console.log(error)
    );
  }
  addOrReplaceAnswer(): UserAnswer {
    let userAnswer: UserAnswer = new UserAnswer();
    userAnswer.questionId = this.currentQuestion.questionId;
    userAnswer.technologyId = 1;
    userAnswer.answer = this.userVote;
    this.userVote = 1;
    this.userAnswers.push(userAnswer);
    return userAnswer;
  }
  nextQuestion(): void {
    if (this.questions.length > this._index) {
      this.addOrReplaceAnswer();
      this.currentQuestion = this.questions[++this._index];
      if (this._index === this.questions.length) {
        this._subscription1 = this._feedbackService.registerFinalFeedback(this.userAnswers).subscribe(result => console.log(result));
      }
    }
  }
  ngOnDestroy(): void {
    if (this._subscription1) this._subscription1.unsubscribe();
    if (this._subscription2) this._subscription2.unsubscribe();
  }
}
