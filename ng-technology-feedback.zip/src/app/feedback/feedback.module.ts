import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";

import { TechnologyFeedbackComponent } from './components/technology-feedback/technology-feedback.component';

import { FeedbackService } from './services/feedback.service';

@NgModule({
  declarations: [
    TechnologyFeedbackComponent
  ],
  providers: [
    FeedbackService
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule
  ],
  exports: [TechnologyFeedbackComponent],
})
export class FeedbackModule { }
