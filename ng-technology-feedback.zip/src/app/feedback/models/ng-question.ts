export class NgQuestion {
  public questionId: number;
  public question: string;
  public answers: any[]
}
