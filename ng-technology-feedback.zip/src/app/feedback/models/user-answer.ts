export class UserAnswer {
  public questionId: number;
  public answer: string | number | boolean;
  public technologyId: number;
}
