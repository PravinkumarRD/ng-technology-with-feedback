import { UserAnswer } from './user-answer';

describe('UserAnswer', () => {
  it('should create an instance', () => {
    expect(new UserAnswer()).toBeTruthy();
  });
});
