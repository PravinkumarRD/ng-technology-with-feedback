import { NgQuestion } from './ng-question';

describe('NgQuestion', () => {
  it('should create an instance', () => {
    expect(new NgQuestion()).toBeTruthy();
  });
});
