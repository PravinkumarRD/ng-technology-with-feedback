import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { NgQuestion } from "../models/ng-question";
import { UserAnswer } from "../models/user-answer";

@Injectable()
export class FeedbackService {
  constructor(private _httpClient: HttpClient) {

  }
  getAngularQuestions(): Observable<NgQuestion[]> {
    return this._httpClient.get<NgQuestion[]>("http://localhost:9090/api/feedback/ngquestions");
  }
  registerFinalFeedback(feedbackResult: UserAnswer[]): Observable<UserAnswer[]> {
    return this._httpClient.post<UserAnswer[]>("http://localhost:9090/api/feedback/finalfeedback", feedbackResult);
  }
}
